const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const time = (ms) => new Date(ms).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", second: "2-digit" });
const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"], DAYPARTS = ["morning", "afternoon", "evening"];
const STATUS_TEXT = { queued: "Waiting", offered: "Has the offer", accepted: "Accepted", declined: "Declined", other_time: "Wants another time", timed_out: "No reply", withdrawn: "Offer withdrawn", busy: "Skipped (holding another offer)", send_failed: "Text failed" };
const PILL = { searching: ["Searching", "wait"], offered: ["Offering", "offering"], filled: ["Filled", "filled"], cancelled: ["Closed", "closed"], exhausted: ["Nobody left", "alert"], expired: ["Too close to start", "alert"] };
let data = { openings: [], waitlist: [], messages: [], notifications: [] };
let formsReady = false;

async function api(path, options) {
  const response = await fetch(path, { headers: { "content-type": "application/json" }, ...options });
  const body = response.status === 204 ? {} : await response.json();
  if (!response.ok) throw new Error(body.error || "Something went wrong.");
  return body;
}

function setupForms(d) {
  const fill = (el, items) => (el.innerHTML = items.map((x) => `<option>${esc(x)}</option>`).join(""));
  fill($("service"), d.services); fill($("stylist"), d.stylists); fill($("w-service"), d.services);
  $("w-stylist").innerHTML = `<option value="any">No preference</option>` + d.stylists.map((x) => `<option>${esc(x)}</option>`).join("");
  $("hold").value = d.defaultHoldMinutes;
  $("w-days").innerHTML = DAYS.map((x) => `<label><input type="checkbox" name="day" value="${x}" /> ${x}</label>`).join("");
  $("w-dayparts").innerHTML = DAYPARTS.map((x) => `<label><input type="checkbox" name="part" value="${x}" /> ${x}</label>`).join("");
  const t = new Date(Date.now() + 3 * 3600_000); t.setMinutes(Math.ceil(t.getMinutes() / 15) * 15, 0, 0);
  $("start").value = new Date(t.getTime() - t.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  formsReady = true;
}

function renderWaitlist() {
  $("waitlist-count").textContent = `(${data.waitlist.filter((w) => w.status === "active").length} waiting)`;
  $("waitlist").innerHTML = data.waitlist.map((w) => `
    <li class="wl"><span><strong>${esc(w.name)}</strong>${w.status === "booked" ? " · booked" : ""}
      <small>${esc(w.service)} · ${w.preferredStylist === "any" ? "any stylist" : esc(w.preferredStylist)} · ${w.days.length ? w.days.join("/") : "any day"} · ${w.dayparts.length ? w.dayparts.join("/") : "any time"}</small>
      <small>Joined ${new Date(w.joinedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</small></span>
      <button class="ghost small" data-remove="${esc(w.id)}" aria-label="Remove ${esc(w.name)}">Remove</button></li>`).join("") || `<li class="empty">Nobody on the waitlist.</li>`;
  const select = $("sim-who"), current = select.value;
  select.innerHTML = data.waitlist.map((w) => `<option value="${esc(w.phone)}">${esc(w.name)}</option>`).join("");
  if (current) select.value = current;
}

function renderOpenings() {
  $("openings").innerHTML = data.openings.map((o) => {
    const [label, cls] = PILL[o.status] || [o.status, "closed"];
    const cur = o.currentOffer;
    const holder = cur ? data.waitlist.find((w) => w.id === cur.candidateId) : null;
    const buttons = holder ? ["YES|Yes", "NO|No", "Can we do a different time?|Another time"].map((x) => { const [text, name] = x.split("|"); return `<button class="small" data-reply="${esc(holder.phone)}" data-text="${esc(text)}">${name}</button>`; }).join("") : "";
    return `<article class="opening" aria-label="${esc(o.opening.service)} opening">
      <header><div><h3>${esc(o.opening.service)} · ${esc(o.opening.stylist)}</h3><div class="when">${esc(o.opening.startLabel)}</div></div><span class="pill ${cls}">${label}</span></header>
      ${cur ? `<div class="holder"><div class="big">${esc(cur.name)} has the offer · <span class="timer" data-expires="${cur.expiresAt}"></span></div>
        <div class="actions"><span class="label">Pretend ${esc(cur.name.split(" ")[0])} replies:</span>${buttons}</div>
        <div class="actions"><button class="small danger" data-withdraw="${esc(o.id)}">Withdraw this offer</button><button class="small danger" data-close="${esc(o.id)}">Close opening</button></div></div>` : ""}
      ${o.winner ? `<div class="filled-banner"><strong>${esc(o.winner.name)}</strong> accepted. Add the booking in Square.</div>` : ""}
      ${o.status === "exhausted" ? `<div class="holder" style="background:var(--red-soft)">Nobody is left to offer this to. It is still open, so please fill it by hand.</div>` : ""}
      <ul class="people">${o.candidates.map((c) => `<li><span>#${c.position} ${esc(c.name)}</span><span class="status s-${c.status}">${c.status === "queued" && ["filled", "cancelled", "exhausted", "expired"].includes(o.status) ? "Not contacted" : (STATUS_TEXT[c.status] || c.status)}</span></li>`).join("") || `<li>No one on the waitlist fits this opening.</li>`}</ul>
      <details><summary>What happened</summary><div class="timeline">${o.events.map((e) => `<div>${time(e.at)} · ${esc(e.text)}</div>`).join("")}</div></details>
    </article>`;
  }).join("") || `<p class="empty">No openings yet. Open a slot on the left to start.</p>`;
  tick();
}

function renderAlerts() {
  $("alerts").innerHTML = data.notifications.map((n) => `<li><span class="tag ${esc(n.event)}">${esc(n.event.replace("_", " "))}</span>${esc(n.text)}<div class="meta hint">${time(n.at)}</div></li>`).join("") || `<li class="empty">Nothing yet.</li>`;
  $("messages").innerHTML = data.messages.map((m) => `<li class="msg ${m.direction}"><div class="meta">${m.direction === "out" ? "To" : "From"} ${esc(m.name)} · ${time(m.at)}</div>${esc(m.body)}</li>`).join("") || `<li class="empty">No texts yet.</li>`;
}

function tick() {
  document.querySelectorAll("[data-expires]").forEach((el) => {
    const left = Math.max(0, Math.round((Number(el.dataset.expires) - Date.now()) / 1000));
    el.textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")} left`;
  });
}

async function refresh() {
  try {
    const d = await api("/api/overview"); data = d;
    if (!formsReady) setupForms(d);
    renderWaitlist(); renderOpenings(); renderAlerts();
  } catch (error) { console.error(error); }
}

async function sendText(from, body) {
  const result = await api("/api/sms/inbound", { method: "POST", body: JSON.stringify({ from, body }) });
  $("sim-result").textContent = result.handled ? `Handled: ${result.result.outcome}.` : result.needsPerson ? "Not clear. Lena was alerted to answer by hand." : "That text did not match an open offer.";
  refresh();
}

document.addEventListener("click", async (event) => {
  const t = event.target.closest("button"); if (!t) return;
  try {
    if (t.dataset.reply) await sendText(t.dataset.reply, t.dataset.text);
    if (t.dataset.withdraw) { await api(`/api/openings/${t.dataset.withdraw}/withdraw`, { method: "POST" }); setTimeout(refresh, 400); }
    if (t.dataset.close) { const reason = prompt("Why are you closing it? (for the record)", "filled another way"); if (reason !== null) { await api(`/api/openings/${t.dataset.close}/close`, { method: "POST", body: JSON.stringify({ reason }) }); setTimeout(refresh, 400); } }
    if (t.dataset.remove) { await api(`/api/waitlist/${t.dataset.remove}`, { method: "DELETE" }); refresh(); }
  } catch (error) { alert(error.message); }
});

$("open-form").addEventListener("submit", async (event) => {
  event.preventDefault(); $("open-error").textContent = "";
  try {
    await api("/api/openings", { method: "POST", body: JSON.stringify({ service: $("service").value, stylist: $("stylist").value, startLocal: $("start").value, holdMinutes: $("quick").checked ? 20 / 60 : Number($("hold").value) }) });
    refresh(); setTimeout(refresh, 600);
  } catch (error) { $("open-error").textContent = error.message; }
});
$("add-form").addEventListener("submit", async (event) => {
  event.preventDefault(); $("add-error").textContent = "";
  const picked = (name) => [...document.querySelectorAll(`input[name=${name}]:checked`)].map((x) => x.value);
  try {
    await api("/api/waitlist", { method: "POST", body: JSON.stringify({ name: $("w-name").value, phone: $("w-phone").value, service: $("w-service").value, preferredStylist: $("w-stylist").value, days: picked("day"), dayparts: picked("part") }) });
    event.target.reset(); refresh();
  } catch (error) { $("add-error").textContent = error.message; }
});
$("sim-form").addEventListener("submit", async (event) => { event.preventDefault(); await sendText($("sim-who").value, $("sim-text").value); $("sim-text").value = ""; });
$("reset").addEventListener("click", async () => { if (confirm("Reset the waitlist and clear all texts and alerts?")) { await api("/api/reset", { method: "POST" }); location.reload(); } });

refresh(); setInterval(refresh, 1500); setInterval(tick, 500);
