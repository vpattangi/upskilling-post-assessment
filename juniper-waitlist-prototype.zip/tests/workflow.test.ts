import assert from "node:assert/strict";
import { test } from "node:test";
import { TestWorkflowEnvironment } from "@temporalio/testing";
import { Worker } from "@temporalio/worker";
import { createActivities } from "../src/activities";
import { normalizePhone } from "../src/policy";
import { JsonStore } from "../src/store";
import type { OpeningInput, OpeningState } from "../src/types";
import { closeOpening, fillOpeningWorkflow, getOpeningState, submitReply, withdrawOffer } from "../src/workflows";

// These tests run against a real local Temporal dev server (started and stopped for you), in real time, so replies sent
// as Updates, timers and retries behave exactly as they do in the app. The server downloads on first run. Set
// TEMPORAL_TEST_SERVER_PATH to an existing `temporal` CLI binary to run offline.
async function createEnvironment(): Promise<TestWorkflowEnvironment> {
  const path = process.env.TEMPORAL_TEST_SERVER_PATH;
  return path
    ? TestWorkflowEnvironment.createLocal({ server: { executable: { type: "existing-path", path } } })
    : TestWorkflowEnvironment.createLocal();
}

let counter = 0;
function slot(overrides: Partial<OpeningInput> = {}): OpeningInput {
  counter += 1;
  return {
    openingId: `opening-test-${counter}`, service: "Women's cut", stylist: "Ana", startMs: Date.now() + 3 * 86_400_000,
    startLabel: "Sat, 2:30 pm", weekday: "sat", daypart: "afternoon", holdMinutes: 30, ...overrides,
  };
}
const pause = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

async function withSalon(
  options: { failFirstAttemptFor?: (key: string) => boolean },
  body: (ctx: {
    env: TestWorkflowEnvironment; store: JsonStore;
    start: (o: OpeningInput) => Promise<ReturnType<TestWorkflowEnvironment["client"]["workflow"]["getHandle"]>>;
    state: (id: string) => Promise<OpeningState>;
    until: (id: string, check: (s: OpeningState) => boolean) => Promise<OpeningState>;
  }) => Promise<void>,
): Promise<void> {
  const env = await createEnvironment();
  const store = new JsonStore();
  try {
    const worker = await Worker.create({
      connection: env.nativeConnection, taskQueue: "salon-test", workflowsPath: require.resolve("../src/workflows"),
      activities: createActivities({ store, failFirstAttemptFor: options.failFirstAttemptFor }),
    });
    await worker.runUntil(async () => {
      const state = (id: string) => env.client.workflow.getHandle(id).query(getOpeningState);
      const until = async (id: string, check: (s: OpeningState) => boolean): Promise<OpeningState> => {
        for (let i = 0; i < 200; i += 1) {
          try { const s = await state(id); if (check(s)) return s; } catch { /* workflow still starting */ }
          await pause(50);
        }
        throw new Error("Timed out waiting for the opening to reach the expected state.");
      };
      const start = async (o: OpeningInput) => {
        await env.client.workflow.start(fillOpeningWorkflow, { workflowId: o.openingId, taskQueue: "salon-test", args: [o] });
        return env.client.workflow.getHandle(o.openingId);
      };
      await body({ env, store, start, state, until });
    });
  } finally {
    await env.teardown();
  }
}
const holder = (s: OpeningState): string | undefined => s.currentOffer?.candidateId;
const sentTo = (store: JsonStore, kind: string): string[] => store.listMessages().filter((m) => m.kind === kind).map((m) => m.name);

test("the first client to say yes gets the slot, and nobody behind them is ever contacted", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    const result = await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "yes" }] });
    assert.equal(result.outcome, "accepted");
    const final = await handle.result();
    assert.equal(final.status, "filled");
    assert.equal(final.winner?.name, "Maya Thompson");
    assert.deepEqual(sentTo(store, "offer"), ["Maya Thompson"], "only the first client was offered the slot");
    assert.deepEqual(sentTo(store, "confirmed"), ["Maya Thompson"]);
    assert.equal(store.listWaitlist().find((e) => e.id === "w1")?.status, "booked");
    assert.ok(store.listNotifications().some((n) => n.event === "accepted" && /Square/.test(n.text)), "Lena is told right away, with a Square reminder");
  });
});

test("a decline moves to the next client automatically", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "no" }] });
    await until(o.openingId, (s) => holder(s) === "w3");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    const final = await handle.result();
    assert.equal(final.winner?.name, "Sofia Ramirez");
    assert.deepEqual(sentTo(store, "offer"), ["Maya Thompson", "Sofia Ramirez"]);
    assert.ok(store.listNotifications().some((n) => n.event === "declined"));
  });
});

test("asking for another time keeps the client on the waitlist and moves on", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "other_time" }] });
    await until(o.openingId, (s) => holder(s) === "w3");
    assert.deepEqual(sentTo(store, "kept_on_waitlist"), ["Maya Thompson"]);
    assert.equal(store.listWaitlist().find((e) => e.id === "w1")?.status, "active");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    await handle.result();
  });
});

test("no reply: the offer times out, the next client is offered, and a late yes cannot claim the slot", async () => {
  await withSalon({}, async ({ env, store, start, until }) => {
    const o = slot({ holdMinutes: 0.05 }); const handle = await start(o); // 3-second hold
    await until(o.openingId, (s) => holder(s) === "w1");
    await env.sleep(3_500);
    await until(o.openingId, (s) => holder(s) === "w3");
    assert.ok(store.listNotifications().some((n) => n.event === "timed_out"), "Lena is told about the timeout");
    const late = await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "yes" }] });
    assert.equal(late.outcome, "late");
    assert.ok(sentTo(store, "no_longer_available").includes("Maya Thompson"), "the late client is told, politely");
    const mid = await handle.query(getOpeningState);
    assert.equal(holder(mid), "w3", "the late yes did not take the offer away from the current holder");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    assert.equal((await handle.result()).winner?.name, "Sofia Ramirez");
  });
});

test("two clients answering yes at the same moment: only the client holding the offer gets it", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    // Sofia (w3) was never offered the slot, but her "yes" is sent first. Maya (w1) holds the offer.
    const [sofia, maya] = await Promise.all([
      handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] }),
      handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "yes" }] }),
    ]);
    assert.equal(sofia.outcome, "late", "a client who does not hold the offer cannot claim it");
    assert.equal(maya.outcome, "accepted");
    const final = await handle.result();
    assert.equal(final.status, "filled");
    assert.equal(final.winner?.name, "Maya Thompson");
    assert.deepEqual(sentTo(store, "confirmed"), ["Maya Thompson"], "only one confirmation text exists");
    assert.ok(sentTo(store, "no_longer_available").includes("Sofia Ramirez"));
  });
});

test("Lena withdraws an offer: the client is told and the next client is offered", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    await handle.signal(withdrawOffer);
    await until(o.openingId, (s) => holder(s) === "w3");
    assert.deepEqual(sentTo(store, "withdrawn"), ["Maya Thompson"]);
    assert.ok(store.listNotifications().some((n) => n.event === "withdrawn"));
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    await handle.result();
  });
});

test("Lena closes the opening: the holder is told and nobody else is contacted", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    await handle.signal(closeOpening, "filled in Square");
    const final = await handle.result();
    assert.equal(final.status, "cancelled");
    assert.deepEqual(sentTo(store, "offer"), ["Maya Thompson"]);
    assert.deepEqual(sentTo(store, "withdrawn"), ["Maya Thompson"]);
    assert.ok(store.listNotifications().some((n) => n.event === "closed" && /filled in Square/.test(n.text)));
  });
});

test("everyone declines: Lena is told the slot is still open", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    for (const id of ["w1", "w3", "w6"]) {
      await until(o.openingId, (s) => holder(s) === id);
      await handle.executeUpdate(submitReply, { args: [{ candidateId: id, reply: "no" }] });
    }
    const final = await handle.result();
    assert.equal(final.status, "exhausted");
    assert.ok(store.listNotifications().some((n) => n.event === "exhausted" && /by hand/.test(n.text)));
  });
});

test("too close to the appointment: no offers go out and Lena is told", async () => {
  await withSalon({}, async ({ store, start }) => {
    const o = slot({ startMs: Date.now() + 5 * 60_000 }); const handle = await start(o);
    const final = await handle.result();
    assert.equal(final.status, "expired");
    assert.equal(sentTo(store, "offer").length, 0);
    assert.ok(store.listNotifications().some((n) => n.event === "expired"));
  });
});

test("a failed text is retried, and the client still gets exactly one offer", async () => {
  await withSalon({ failFirstAttemptFor: (key) => key.startsWith("offer:") }, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    assert.equal(store.listMessages().filter((m) => m.kind === "offer" && m.name === "Maya Thompson").length, 1);
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "yes" }] });
    await handle.result();
  });
});

test("nobody is contacted twice for the same slot, and a duplicate signup is never texted", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    for (const id of ["w1", "w3", "w6"]) {
      await until(o.openingId, (s) => holder(s) === id);
      await handle.executeUpdate(submitReply, { args: [{ candidateId: id, reply: "no" }] });
    }
    await handle.result();
    const offers = store.listMessages().filter((m) => m.kind === "offer").map((m) => normalizePhone(m.phone));
    assert.equal(new Set(offers).size, offers.length, "each phone number got at most one offer");
    assert.ok(!sentTo(store, "offer").includes("Maya T."), "Maya's second signup was not texted");
  });
});

test("a client never sees anyone else's name, number or place in line", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const o = slot(); const handle = await start(o);
    await until(o.openingId, (s) => holder(s) === "w1");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "no" }] });
    await until(o.openingId, (s) => holder(s) === "w3");
    await handle.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    await handle.result();
    for (const message of store.listMessages().filter((m) => m.direction === "out")) {
      for (const other of store.listWaitlist().filter((e) => e.name !== message.name)) {
        const first = other.name.split(" ")[0]!;
        const sameFirstName = message.name.split(" ")[0] === first;
        if (!sameFirstName) assert.ok(!message.body.includes(first), `"${message.body}" mentions ${first}`);
        assert.ok(!message.body.includes(normalizePhone(other.phone).slice(-4)), "no other phone numbers");
      }
      assert.ok(!/#\d|position|in line|waitlist position/i.test(message.body), "no place in line");
    }
  });
});

test("a client holds one offer at a time: a second opening skips them and offers the next client", async () => {
  await withSalon({}, async ({ store, start, until }) => {
    const a = slot({ openingId: "opening-ana-a" }); const b = slot({ openingId: "opening-ana-b", startLabel: "Sat, 4:00 pm" });
    const handleA = await start(a);
    await until(a.openingId, (s) => holder(s) === "w1");
    const handleB = await start(b);
    await until(b.openingId, (s) => holder(s) === "w3");
    const stateB = await handleB.query(getOpeningState);
    assert.equal(stateB.candidates.find((c) => c.candidateId === "w1")?.status, "busy");
    await handleA.executeUpdate(submitReply, { args: [{ candidateId: "w1", reply: "yes" }] });
    await handleB.executeUpdate(submitReply, { args: [{ candidateId: "w3", reply: "yes" }] });
    await Promise.all([handleA.result(), handleB.result()]);
    assert.equal(sentTo(store, "offer").filter((n) => n === "Maya Thompson").length, 1);
  });
});
