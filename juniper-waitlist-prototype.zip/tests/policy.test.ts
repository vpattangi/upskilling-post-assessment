import assert from "node:assert/strict";
import { test } from "node:test";
import { effectiveHoldMs, fitsOpening, holdLabel, normalizePhone, parseReply, rankCandidates } from "../src/policy";
import { seedWaitlist } from "../src/seed";
import type { OpeningInput } from "../src/types";

const saturdayAfternoon: OpeningInput = {
  openingId: "o", service: "Women's cut", stylist: "Ana", startMs: Date.now() + 86_400_000,
  startLabel: "Sat, 2:30 pm", weekday: "sat", daypart: "afternoon", holdMinutes: 15,
};

test("earliest sign-up goes first among clients who fit service, stylist and availability", () => {
  const ranked = rankCandidates(seedWaitlist(), saturdayAfternoon);
  assert.deepEqual(ranked.map((c) => c.name), ["Maya Thompson", "Sofia Ramirez", "Hannah Brooks"]);
  assert.deepEqual(ranked.map((c) => c.position), [1, 2, 3]);
});

test("clients who do not fit are never offered the slot", () => {
  const names = rankCandidates(seedWaitlist(), saturdayAfternoon).map((c) => c.name);
  assert.ok(!names.includes("Grace Kim"), "Grace only wants Mei in the morning");
  assert.ok(!names.includes("Jordan Lee"), "Jordan wants a men's cut");
  const evening = rankCandidates(seedWaitlist(), { ...saturdayAfternoon, weekday: "tue", daypart: "morning" });
  assert.ok(!evening.map((c) => c.name).includes("Sofia Ramirez"), "Sofia is only free Fri/Sat afternoons and evenings");
});

test("a person who signed up twice (same phone) is contacted once", () => {
  const ranked = rankCandidates(seedWaitlist(), saturdayAfternoon);
  const phones = ranked.map((c) => normalizePhone(c.phone));
  assert.equal(new Set(phones).size, phones.length);
  assert.ok(!ranked.some((c) => c.name === "Maya T."));
});

test("a booked client is not offered another slot", () => {
  const list = seedWaitlist().map((e) => (e.id === "w1" ? { ...e, status: "booked" as const } : e));
  assert.ok(!rankCandidates(list, saturdayAfternoon).some((c) => c.candidateId === "w1"));
  assert.equal(fitsOpening(list[0]!, saturdayAfternoon), false);
});

test("short-notice slots shorten the hold so one slow reply cannot block them", () => {
  assert.equal(effectiveHoldMs(15, 48 * 3_600_000), 15 * 60_000);
  assert.equal(effectiveHoldMs(15, 40 * 60_000), 10 * 60_000);
  assert.equal(effectiveHoldMs(15, 12 * 60_000), 3 * 60_000);
  assert.equal(effectiveHoldMs(15, 6 * 60_000), 2 * 60_000, "never shorter than a 2-minute floor");
  assert.equal(effectiveHoldMs(0.05, 48 * 3_600_000), 3_000);
  assert.equal(holdLabel(3_000), "3 seconds");
  assert.equal(holdLabel(15 * 60_000), "15 minutes");
});

test("replies are understood in plain words", () => {
  assert.equal(parseReply("YES"), "yes");
  assert.equal(parseReply("yes please!"), "yes");
  assert.equal(parseReply("No thanks"), "no");
  assert.equal(parseReply("can we do a different time?"), "other_time");
  assert.equal(parseReply("yes but how about Friday"), "other_time");
  assert.equal(parseReply("hmm who is this"), "unknown");
});
