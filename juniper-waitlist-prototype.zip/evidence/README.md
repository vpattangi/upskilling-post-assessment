# Evidence

`temporal-ui-workflow.png` is a Temporal Web UI screenshot of one real run of `fillOpeningWorkflow`
(Workflow ID `opening-ana-20261010T1430`, status Completed). The compact event history shows, in order:

- `findCandidates` ranking the waitlist,
- `sendOffer` to the first client, then a 6-second **Timer** for her hold (she did not reply),
- a second `sendOffer` to the next client and a second Timer,
- two **Workflow Updates** named `submitReply`: the second client's "yes" (outcome `accepted`) and the first client's late "yes" (outcome `late`),
- `releaseOffer`, `sendClientNotice` (confirmation, and "no longer available" for the late client), `markBooked`, and `notifyOwner` (the alert to Lena).

All names and phone numbers are fictional demo data. To reproduce it, run `npm run dev`, then `npm run smoke`,
and open the Workflow in the Temporal UI at http://localhost:8233.
