// Pure business rules. No Node or Temporal imports, so they are safe inside a Workflow and easy to test.
import type { Candidate, OpeningInput, ReplyKind, WaitlistEntry } from "./types";

export function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  return digits.length === 11 && digits.startsWith("1") ? digits.slice(1) : digits;
}

export function fitsOpening(entry: WaitlistEntry, opening: OpeningInput): boolean {
  if (entry.status !== "active") return false;
  if (entry.service !== opening.service) return false;
  if (entry.preferredStylist !== "any" && entry.preferredStylist !== opening.stylist) return false;
  if (entry.days.length > 0 && !entry.days.includes(opening.weekday)) return false;
  if (entry.dayparts.length > 0 && !entry.dayparts.includes(opening.daypart)) return false;
  return true;
}

/**
 * Lena's rule: among people who fit the service, availability and stylist preference,
 * whoever joined the waitlist first goes first. A person who appears twice (same phone)
 * is only ever contacted once.
 */
export function rankCandidates(entries: WaitlistEntry[], opening: OpeningInput): Candidate[] {
  const fitting = entries
    .filter((entry) => fitsOpening(entry, opening))
    .sort((a, b) => a.joinedAt.localeCompare(b.joinedAt) || a.id.localeCompare(b.id));
  const seen = new Set<string>();
  const unique = fitting.filter((entry) => {
    const phone = normalizePhone(entry.phone);
    if (seen.has(phone)) return false;
    seen.add(phone);
    return true;
  });
  return unique.map((entry, index) => ({
    candidateId: entry.id,
    name: entry.name,
    firstName: entry.name.split(" ")[0] ?? entry.name,
    phone: entry.phone,
    position: index + 1,
  }));
}

/**
 * How long one client may hold an offer. Never longer than Lena's setting, and shorter when the
 * appointment is close, so a short-notice opening is not blocked by one slow reply.
 * ASSUMPTION: Lena did not give a number, so this is configurable per opening.
 */
export function effectiveHoldMs(holdMinutes: number, untilStartMs: number): number {
  const wanted = holdMinutes * 60_000;
  const cap = Math.max(2 * 60_000, untilStartMs / 4);
  return Math.max(1_000, Math.min(wanted, cap));
}

export function holdLabel(holdMs: number): string {
  if (holdMs < 60_000) return `${Math.round(holdMs / 1000)} seconds`;
  const minutes = Math.round(holdMs / 60_000);
  return minutes === 1 ? "1 minute" : `${minutes} minutes`;
}

const OTHER = /(another|different|other time|other day|later|earlier|can'?t make|cannot make|what about|how about|instead|reschedule)/i;
const YES = /^\s*(y|yes|yep|yeah|yup|sure|ok|okay|please|book it)\b/i;
const NO = /^\s*(n|no|nope|pass|no thanks|not now)\b/i;

export function parseReply(text: string): ReplyKind | "unknown" {
  if (OTHER.test(text)) return "other_time";
  if (YES.test(text)) return "yes";
  if (NO.test(text)) return "no";
  return "unknown";
}

export const LATE_TEXT = (firstName: string, slotLabel: string): string =>
  `Sorry ${firstName}, that opening (${slotLabel}) is no longer available. You're still on the waitlist for other openings.`;
