import { randomUUID } from "node:crypto";
import path from "node:path";
import { Client, Connection, WorkflowExecutionAlreadyStartedError } from "@temporalio/client";
import express, { type NextFunction, type Request, type Response } from "express";
import { DEFAULT_HOLD_MINUTES, MIN_LEAD_MS, OWNER_NAME, SALON_NAME, SERVICES, STYLISTS, TASK_QUEUE } from "./config";
import { LATE_TEXT, normalizePhone, parseReply } from "./policy";
import { JsonStore } from "./store";
import type { Daypart, OpeningInput, OpeningState, ReplyResult, Weekday, WaitlistEntry } from "./types";
import { closeOpening, fillOpeningWorkflow, getOpeningState, submitReply, withdrawOffer } from "./workflows";

const app = express();
app.use(express.json());
app.use(express.static(path.join(process.cwd(), "public")));
const store = new JsonStore(path.join(process.cwd(), "data", "runtime.json"));

let clientPromise: Promise<Client> | undefined;
function getClient(): Promise<Client> {
  clientPromise ??= Connection.connect({
    address: process.env.TEMPORAL_ADDRESS ?? "localhost:7233",
  }).then((connection) => new Client({ connection, namespace: "default" }));
  return clientPromise;
}

const WEEKDAYS: Weekday[] = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
const daypartOf = (hour: number): Daypart => (hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening");
class BadRequest extends Error {}

function describeStart(date: Date): string {
  const day = date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
  const time = date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }).toLowerCase();
  return `${day}, ${time}`;
}

async function stateOf(id: string): Promise<OpeningState | undefined> {
  const client = await getClient();
  try { return await client.workflow.getHandle(id).query(getOpeningState); } catch { return undefined; }
}

// ---- Overview used by the browser (one poll gives it everything it draws) ----
app.get("/api/overview", async (_req, res) => {
  const states = await Promise.all(store.listOpenings().map(async (id) => ({ id, state: await stateOf(id) })));
  res.json({
    salon: SALON_NAME, owner: OWNER_NAME, services: SERVICES, stylists: STYLISTS, defaultHoldMinutes: DEFAULT_HOLD_MINUTES,
    waitlist: store.listWaitlist(),
    openings: states.filter((s) => s.state).map((s) => ({ id: s.id, ...s.state })).reverse(),
    notifications: store.listNotifications().slice(-40).reverse(),
    messages: store.listMessages().slice(-60).reverse(),
  });
});

// ---- Lena opens a slot ----
app.post("/api/openings", async (req, res) => {
  const { service, stylist, startLocal, holdMinutes } = req.body as Record<string, string | number>;
  if (!SERVICES.includes(String(service))) throw new BadRequest("Pick a service.");
  if (!STYLISTS.includes(String(stylist))) throw new BadRequest("Pick a stylist.");
  const start = new Date(String(startLocal));
  if (Number.isNaN(start.getTime())) throw new BadRequest("Pick a date and time.");
  if (start.getTime() - Date.now() < MIN_LEAD_MS) throw new BadRequest("That time is too close or already past. Offers need at least 10 minutes of notice.");
  const hold = Number(holdMinutes ?? DEFAULT_HOLD_MINUTES);
  if (!(hold > 0 && hold <= 240)) throw new BadRequest("Hold time must be between a few seconds and 4 hours.");

  // The same slot gets the same Workflow ID, so it cannot be opened twice at once.
  const openingId = `opening-${String(stylist).toLowerCase()}-${String(startLocal).replace(/[^0-9T]/g, "")}`;
  const input: OpeningInput = {
    openingId, service: String(service), stylist: String(stylist), startMs: start.getTime(), startLabel: describeStart(start),
    weekday: WEEKDAYS[start.getDay()] as Weekday, daypart: daypartOf(start.getHours()), holdMinutes: hold,
  };
  const client = await getClient();
  try {
    await client.workflow.start(fillOpeningWorkflow, { workflowId: openingId, taskQueue: TASK_QUEUE, args: [input] });
  } catch (error) {
    if (error instanceof WorkflowExecutionAlreadyStartedError) {
      res.status(409).json({ error: "Offers for this slot are already running. Close that opening first if you want to restart it." });
      return;
    }
    throw error;
  }
  store.addOpening(openingId);
  res.status(201).json({ openingId });
});

app.post("/api/openings/:id/withdraw", async (req, res) => {
  const client = await getClient();
  await client.workflow.getHandle(req.params.id).signal(withdrawOffer);
  res.status(202).json({ accepted: true });
});
app.post("/api/openings/:id/close", async (req, res) => {
  const client = await getClient();
  await client.workflow.getHandle(req.params.id).signal(closeOpening, String(req.body?.reason ?? "closed by the salon"));
  res.status(202).json({ accepted: true });
});

// ---- Inbound text (simulated). A real SMS provider would call this same endpoint. ----
app.post("/api/sms/inbound", async (req, res) => {
  const { from, body } = req.body as { from: string; body: string };
  store.recordMessage({ key: `in:${randomUUID()}`, at: Date.now(), direction: "in", phone: from, name: store.getConversation(from)?.name ?? from, kind: "reply", body });
  const conversation = store.getConversation(from);
  if (!conversation) {
    store.recordNotification({ key: `unmatched:${randomUUID()}`, at: Date.now(), event: "needs_attention", text: `A text from ${from} did not match any open offer: "${body}".` });
    res.json({ handled: false });
    return;
  }
  const intent = parseReply(String(body));
  if (intent === "unknown") {
    store.recordNotification({ key: `unclear:${randomUUID()}`, at: Date.now(), event: "needs_attention", text: `${conversation.name} replied "${body}", which needs a person to answer.`, openingId: conversation.openingId });
    res.json({ handled: false, needsPerson: true });
    return;
  }
  const client = await getClient();
  try {
    const result: ReplyResult = await client.workflow.getHandle(conversation.openingId).executeUpdate(submitReply, {
      args: [{ candidateId: conversation.candidateId, reply: intent }],
    });
    res.json({ handled: true, result });
  } catch {
    // The opening already finished, so there is no Workflow left to ask.
    store.recordMessage({
      key: `late-closed:${conversation.openingId}:${conversation.candidateId}`, at: Date.now(), direction: "out", phone: from, name: conversation.name,
      kind: "no_longer_available", body: LATE_TEXT(conversation.firstName, conversation.slotLabel), openingId: conversation.openingId,
    });
    res.json({ handled: true, result: { outcome: "late", message: "That opening is already finished." } });
  }
});

// ---- Waitlist (replaces the Google Sheet for the prototype) ----
app.post("/api/waitlist", (req, res) => {
  const b = req.body as Partial<WaitlistEntry>;
  if (!b.name || !b.phone || !b.service) throw new BadRequest("Name, phone and service are required.");
  const entry: WaitlistEntry = {
    id: `w-${randomUUID().slice(0, 8)}`, name: String(b.name), phone: String(b.phone), service: String(b.service),
    preferredStylist: b.preferredStylist || "any", days: b.days ?? [], dayparts: b.dayparts ?? [], joinedAt: new Date().toISOString(), status: "active",
  };
  if (normalizePhone(entry.phone).length < 10) throw new BadRequest("Enter a full phone number.");
  store.addWaitlist(entry);
  res.status(201).json(entry);
});
app.delete("/api/waitlist/:id", (req, res) => { store.removeWaitlist(req.params.id); res.status(204).end(); });
app.post("/api/reset", async (_req, res) => {
  // Stop any offers still running so they cannot keep texting after the reset.
  const client = await getClient();
  await Promise.all(store.listOpenings().map((id) => client.workflow.getHandle(id).signal(closeOpening, "demo reset").catch(() => undefined)));
  store.reset();
  res.status(204).end();
});

app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof BadRequest) { res.status(400).json({ error: error.message }); return; }
  console.error(error);
  res.status(500).json({ error: error instanceof Error ? error.message : "Unexpected error" });
});

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => console.log(`${SALON_NAME} open-slot assistant is available at http://localhost:${port}`));
