import type { WaitlistEntry } from "./types";

// Fictional clients for the demo. Names and numbers are made up.
export function seedWaitlist(): WaitlistEntry[] {
  const e = (
    id: string, name: string, phone: string, service: string, preferredStylist: string,
    days: WaitlistEntry["days"], dayparts: WaitlistEntry["dayparts"], joinedAt: string,
  ): WaitlistEntry => ({ id, name, phone, service, preferredStylist, days, dayparts, joinedAt, status: "active" });
  return [
    e("w1", "Maya Thompson", "+1 555 555 0101", "Women's cut", "any", [], [], "2026-09-21T10:00:00Z"),
    e("w2", "Jordan Lee", "+1 555 555 0102", "Men's cut", "any", ["sat"], ["morning", "afternoon"], "2026-09-22T09:30:00Z"),
    e("w3", "Sofia Ramirez", "+1 555 555 0103", "Women's cut", "Ana", ["fri", "sat"], ["afternoon", "evening"], "2026-09-23T14:00:00Z"),
    e("w4", "Nate Okafor", "+1 555 555 0104", "Men's cut", "Jordan", [], ["evening"], "2026-09-24T18:10:00Z"),
    e("w5", "Elena Petrova", "+1 555 555 0105", "Color", "Mei", ["thu", "fri"], [], "2026-09-25T11:45:00Z"),
    e("w6", "Hannah Brooks", "+1 555 555 0106", "Women's cut", "any", ["sat", "sun"], [], "2026-09-26T16:20:00Z"),
    e("w7", "Tomas Silva", "+1 555 555 0107", "Blowout", "any", [], [], "2026-09-27T12:00:00Z"),
    e("w8", "Grace Kim", "+1 555 555 0108", "Women's cut", "Mei", [], ["morning"], "2026-09-28T08:15:00Z"),
    // Same person signed up twice: she must only be contacted once per opening.
    e("w9", "Maya T.", "(555) 555-0101", "Women's cut", "Ana", [], [], "2026-09-30T13:00:00Z"),
  ];
}
