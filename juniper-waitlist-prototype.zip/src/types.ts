export type Daypart = "morning" | "afternoon" | "evening";
export type Weekday = "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun";

/** One person on the waitlist (replaces a row in the Google Sheet). */
export interface WaitlistEntry {
  id: string;
  name: string;
  phone: string;
  service: string;
  /** A stylist's name, or "any". */
  preferredStylist: string;
  /** Empty means any day. */
  days: Weekday[];
  /** Empty means any time of day. */
  dayparts: Daypart[];
  joinedAt: string;
  status: "active" | "booked";
}

/** What Lena enters when a slot opens. Everything the Workflow needs is plain data. */
export interface OpeningInput {
  openingId: string;
  service: string;
  stylist: string;
  startMs: number;
  startLabel: string;
  weekday: Weekday;
  daypart: Daypart;
  holdMinutes: number;
}

export interface Candidate {
  candidateId: string;
  name: string;
  firstName: string;
  phone: string;
  /** Place in line among clients who fit this opening (1 = joined the waitlist first). */
  position: number;
}

export type CandidateStatus =
  | "queued"
  | "offered"
  | "accepted"
  | "declined"
  | "other_time"
  | "timed_out"
  | "withdrawn"
  | "busy"
  | "send_failed";

export interface CandidateProgress extends Candidate {
  status: CandidateStatus;
  offeredAt?: number;
  resolvedAt?: number;
}

export type OpeningStatus = "searching" | "offered" | "filled" | "cancelled" | "exhausted" | "expired";

export interface OpeningEvent {
  at: number;
  text: string;
}

export interface OpeningState {
  opening: OpeningInput;
  status: OpeningStatus;
  candidates: CandidateProgress[];
  currentOffer?: { candidateId: string; name: string; offeredAt: number; expiresAt: number };
  winner?: { candidateId: string; name: string };
  events: OpeningEvent[];
  startedAt: number;
  finishedAt?: number;
}

export type ReplyKind = "yes" | "no" | "other_time";
export interface ReplyInput {
  candidateId: string;
  reply: ReplyKind;
}
export interface ReplyResult {
  outcome: "accepted" | "declined" | "other_time" | "late";
  message: string;
}

export type NoticeKind = "confirmed" | "withdrawn" | "no_longer_available" | "kept_on_waitlist";
export type OwnerEvent =
  | "accepted"
  | "declined"
  | "other_time"
  | "timed_out"
  | "withdrawn"
  | "closed"
  | "exhausted"
  | "expired"
  | "send_failed";

/** The side effects the Workflow asks for. Each one is safe to retry. */
export interface ActivityApi {
  findCandidates(opening: OpeningInput): Promise<Candidate[]>;
  sendOffer(args: { opening: OpeningInput; candidate: Candidate; holdMs: number }): Promise<"sent" | "busy">;
  releaseOffer(args: { openingId: string; candidate: Candidate }): Promise<void>;
  sendClientNotice(args: { opening: OpeningInput; candidate: Candidate; kind: NoticeKind }): Promise<void>;
  notifyOwner(args: { opening: OpeningInput; event: OwnerEvent; text: string; dedupeKey: string }): Promise<void>;
  markBooked(args: { candidateId: string }): Promise<void>;
}

export interface Message {
  key: string;
  at: number;
  direction: "out" | "in";
  phone: string;
  name: string;
  kind: string;
  body: string;
  openingId?: string;
}
export interface Notification {
  key: string;
  at: number;
  event: string;
  text: string;
  openingId?: string;
}
export interface Conversation {
  openingId: string;
  candidateId: string;
  name: string;
  firstName: string;
  slotLabel: string;
  at: number;
}
