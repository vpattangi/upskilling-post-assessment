import { Context } from "@temporalio/activity";
import { holdLabel, LATE_TEXT, rankCandidates } from "./policy";
import type { JsonStore } from "./store";
import type { ActivityApi, Candidate, NoticeKind, OpeningInput } from "./types";

export interface ActivityDeps {
  store: JsonStore;
  /** Test hook: make the first attempt of a send fail, to prove retries never double-send. */
  failFirstAttemptFor?: (key: string) => boolean;
}

const slot = (o: OpeningInput): string => `${o.service} with ${o.stylist}, ${o.startLabel}`;

// SMS is SIMULATED: a "sent" text is a row in the outbox. A real provider (for example Twilio) would replace
// the one recordMessage call inside sendText. The idempotency key is what a real provider integration also needs.
export function createActivities({ store, failFirstAttemptFor }: ActivityDeps): ActivityApi {
  function sendText(key: string, candidate: Candidate, kind: string, body: string, openingId: string): void {
    store.recordMessage({ key, at: Date.now(), direction: "out", phone: candidate.phone, name: candidate.name, kind, body, openingId });
    // Test hook: the provider took the text but we never heard back, so Temporal retries. The retry must not text again.
    if (failFirstAttemptFor?.(key) && Context.current().info.attempt === 1) {
      throw new Error("Simulated outage: the text went out but the confirmation was lost");
    }
  }

  return {
    async findCandidates(opening) {
      return rankCandidates(store.listWaitlist(), opening);
    },

    async sendOffer({ opening, candidate, holdMs }) {
      const now = Date.now();
      if (!store.claimHolding(candidate.phone, opening.openingId, now + holdMs + 60_000, now)) return "busy";
      const key = `offer:${opening.openingId}:${candidate.candidateId}`;
      const body = `Hi ${candidate.firstName}, a spot opened at Juniper Salon: ${slot(opening)}. Reply YES to take it or NO to pass. We're holding it for you for ${holdLabel(holdMs)}.`;
      sendText(key, candidate, "offer", body, opening.openingId);
      store.setConversation(candidate.phone, {
        openingId: opening.openingId, candidateId: candidate.candidateId, name: candidate.name,
        firstName: candidate.firstName, slotLabel: `${opening.service}, ${opening.startLabel}`, at: now,
      });
      return "sent";
    },

    async releaseOffer({ openingId, candidate }) {
      store.releaseHolding(candidate.phone, openingId);
    },

    async sendClientNotice({ opening, candidate, kind }) {
      const first = candidate.firstName;
      const bodies: Record<NoticeKind, string> = {
        confirmed: `You're booked, ${first}: ${slot(opening)}. See you then!`,
        withdrawn: `Sorry ${first}, we had to withdraw that offer (${opening.service}, ${opening.startLabel}). You're still on the waitlist.`,
        no_longer_available: LATE_TEXT(first, `${opening.service}, ${opening.startLabel}`),
        kept_on_waitlist: `No problem, ${first}. That time doesn't suit, so we've kept you on the waitlist for other openings.`,
      };
      sendText(`${kind}:${opening.openingId}:${candidate.candidateId}`, candidate, kind, bodies[kind], opening.openingId);
    },

    async notifyOwner({ opening, event, text, dedupeKey }) {
      // Simulated: an alert for Lena in the app and a text to her phone.
      store.recordNotification({ key: `owner:${opening.openingId}:${dedupeKey}`, at: Date.now(), event, text, openingId: opening.openingId });
    },

    async markBooked({ candidateId }) {
      store.markBooked(candidateId);
    },
  };
}
