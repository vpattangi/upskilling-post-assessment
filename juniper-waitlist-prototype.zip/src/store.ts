import fs from "node:fs";
import path from "node:path";
import { seedWaitlist } from "./seed";
import { normalizePhone } from "./policy";
import type { Conversation, Message, Notification, WaitlistEntry } from "./types";

interface Data {
  waitlist: WaitlistEntry[];
  messages: Message[];
  notifications: Notification[];
  holdings: Record<string, { openingId: string; expiresAtMs: number }>;
  conversations: Record<string, Conversation>;
  openings: string[];
}

const fresh = (): Data => ({ waitlist: seedWaitlist(), messages: [], notifications: [], holdings: {}, conversations: {}, openings: [] });

/**
 * A deliberately small store. With a file path it is shared by the API and the Worker (two processes);
 * without one it lives in memory for tests. PRODUCTION WOULD USE A REAL DATABASE.
 */
export class JsonStore {
  private memory?: Data;
  constructor(private readonly file?: string) {}

  private read(): Data {
    if (!this.file) return (this.memory ??= fresh());
    if (!fs.existsSync(this.file)) { const data = fresh(); this.write(data); return data; }
    return JSON.parse(fs.readFileSync(this.file, "utf8")) as Data;
  }
  private write(data: Data): void {
    if (!this.file) { this.memory = data; return; }
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const temp = `${this.file}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(data, null, 2));
    fs.renameSync(temp, this.file);
  }
  private update<T>(change: (data: Data) => T): T {
    const data = this.read();
    const result = change(data);
    this.write(data);
    return result;
  }

  reset(): void { this.write(fresh()); }

  listWaitlist(): WaitlistEntry[] { return this.read().waitlist; }
  addWaitlist(entry: WaitlistEntry): void { this.update((d) => { d.waitlist.push(entry); }); }
  removeWaitlist(id: string): void { this.update((d) => { d.waitlist = d.waitlist.filter((e) => e.id !== id); }); }
  markBooked(id: string): void { this.update((d) => { const e = d.waitlist.find((x) => x.id === id); if (e) e.status = "booked"; }); }

  /** Returns false (and records nothing) if a message with this key already exists. This is what makes retries safe. */
  recordMessage(message: Message): boolean {
    return this.update((d) => {
      if (d.messages.some((m) => m.key === message.key)) return false;
      d.messages.push(message);
      return true;
    });
  }
  listMessages(): Message[] { return this.read().messages; }

  recordNotification(note: Notification): boolean {
    return this.update((d) => {
      if (d.notifications.some((n) => n.key === note.key)) return false;
      d.notifications.push(note);
      return true;
    });
  }
  listNotifications(): Notification[] { return this.read().notifications; }

  /** A client may hold only one offer at a time, across all openings. */
  claimHolding(phone: string, openingId: string, expiresAtMs: number, nowMs: number): boolean {
    const key = normalizePhone(phone);
    return this.update((d) => {
      const held = d.holdings[key];
      if (held && held.openingId !== openingId && held.expiresAtMs > nowMs) return false;
      d.holdings[key] = { openingId, expiresAtMs };
      return true;
    });
  }
  releaseHolding(phone: string, openingId: string): void {
    const key = normalizePhone(phone);
    this.update((d) => { if (d.holdings[key]?.openingId === openingId) delete d.holdings[key]; });
  }

  setConversation(phone: string, conversation: Conversation): void { this.update((d) => { d.conversations[normalizePhone(phone)] = conversation; }); }
  getConversation(phone: string): Conversation | undefined { return this.read().conversations[normalizePhone(phone)]; }

  addOpening(id: string): void { this.update((d) => { if (!d.openings.includes(id)) d.openings.push(id); }); }
  listOpenings(): string[] { return this.read().openings; }
}
