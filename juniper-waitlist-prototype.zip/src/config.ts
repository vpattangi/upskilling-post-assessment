export const TASK_QUEUE = "juniper-waitlist";
export const SALON_NAME = "Juniper Salon";
export const OWNER_NAME = "Lena";
export const SERVICES = ["Women's cut", "Men's cut", "Color", "Blowout"];
export const STYLISTS = ["Ana", "Jordan", "Mei"];
/** Stop offering when the appointment is closer than this. */
export const MIN_LEAD_MS = 10 * 60_000;
export const DEFAULT_HOLD_MINUTES = 15;
