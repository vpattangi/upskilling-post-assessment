import path from "node:path";
import { NativeConnection, Worker } from "@temporalio/worker";
import { createActivities } from "./activities";
import { TASK_QUEUE } from "./config";
import { JsonStore } from "./store";

async function run(): Promise<void> {
  const connection = await NativeConnection.connect({
    address: process.env.TEMPORAL_ADDRESS ?? "localhost:7233",
  });
  const store = new JsonStore(path.join(process.cwd(), "data", "runtime.json"));
  const worker = await Worker.create({
    connection,
    namespace: "default",
    taskQueue: TASK_QUEUE,
    workflowsPath: require.resolve("./workflows"),
    activities: createActivities({ store }),
  });
  console.log(`Worker is polling the ${TASK_QUEUE} task queue.`);
  await worker.run();
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
