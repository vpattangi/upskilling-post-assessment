import {
  allHandlersFinished,
  condition,
  defineQuery,
  defineSignal,
  defineUpdate,
  proxyActivities,
  setHandler,
} from "@temporalio/workflow";
import { MIN_LEAD_MS } from "./config";
import { effectiveHoldMs, holdLabel, LATE_TEXT } from "./policy";
import type {
  ActivityApi, Candidate, CandidateProgress, OpeningInput, OpeningState, OpeningStatus, OwnerEvent, ReplyInput, ReplyResult,
} from "./types";

// Lena can look at any opening at any time, withdraw the current offer, or close the whole opening.
export const getOpeningState = defineQuery<OpeningState>("getOpeningState");
export const withdrawOffer = defineSignal("withdrawOffer");
export const closeOpening = defineSignal<[string]>("closeOpening");
// A client's reply is an Update (not a Signal) so the sender gets an immediate, authoritative answer.
// The Workflow handles one message at a time, so two simultaneous "yes" replies can never both win.
export const submitReply = defineUpdate<ReplyResult, [ReplyInput]>("submitReply");

const acts = proxyActivities<ActivityApi>({
  startToCloseTimeout: "20 seconds",
  retry: { initialInterval: "1 second", backoffCoefficient: 2, maximumInterval: "10 seconds", maximumAttempts: 5 },
});

type Resolution = "accepted" | "declined" | "other_time" | "withdrawn";

/** One durable Workflow per open slot. It offers the slot to one client at a time, in order, until it is filled. */
export async function fillOpeningWorkflow(opening: OpeningInput): Promise<OpeningState> {
  const state: OpeningState = { opening, status: "searching", candidates: [], events: [], startedAt: Date.now() };
  let pending: { candidateId: string; resolution?: Resolution } | undefined;
  let closeRequested = false;
  let closeReason = "";
  const slotLabel = `${opening.service}, ${opening.startLabel}`;

  const log = (text: string): void => { state.events.push({ at: Date.now(), text }); };
  const progressOf = (id: string): CandidateProgress | undefined => state.candidates.find((c) => c.candidateId === id);
  const asCandidate = ({ candidateId, name, firstName, phone, position }: CandidateProgress): Candidate => ({ candidateId, name, firstName, phone, position });
  const tell = (event: OwnerEvent, text: string, dedupeKey: string): Promise<void> => {
    log(text);
    return acts.notifyOwner({ opening, event, text, dedupeKey });
  };
  async function finish(status: OpeningStatus, event: OwnerEvent, text: string): Promise<void> {
    state.status = status;
    state.finishedAt = Date.now();
    await tell(event, text, "final");
  }

  setHandler(getOpeningState, () => state);
  setHandler(withdrawOffer, () => { if (pending && pending.resolution === undefined) pending.resolution = "withdrawn"; });
  setHandler(closeOpening, (reason) => { closeRequested = true; closeReason = reason || "closed by the salon"; });

  setHandler(
    submitReply,
    async ({ candidateId, reply }): Promise<ReplyResult> => {
      const progress = progressOf(candidateId);
      if (!progress) return { outcome: "late", message: "Unknown client." };
      if (pending && pending.candidateId === candidateId && pending.resolution === undefined) {
        pending.resolution = reply === "yes" ? "accepted" : reply === "no" ? "declined" : "other_time";
        const outcome = pending.resolution === "accepted" ? "accepted" : pending.resolution === "declined" ? "declined" : "other_time";
        return { outcome, message: outcome === "accepted" ? "Got it. You're booked." : "Thanks for letting us know." };
      }
      // A repeat of an answer we already took is not "late".
      if (progress.status === "accepted" || progress.status === "declined" || progress.status === "other_time") {
        return { outcome: progress.status, message: "We already have your answer." };
      }
      // Not holding the offer: it timed out, was withdrawn, or the slot is taken or closed.
      log(`${progress.name} replied after their offer ended and was told the slot is no longer available.`);
      await acts.sendClientNotice({ opening, candidate: asCandidate(progress), kind: "no_longer_available" });
      return { outcome: "late", message: LATE_TEXT(progress.firstName, slotLabel) };
    },
    {
      validator: ({ candidateId }) => {
        if (!progressOf(candidateId)) throw new Error("That client is not part of this opening.");
      },
    },
  );

  const found = await acts.findCandidates(opening);
  state.candidates = found.map((c) => ({ ...c, status: "queued" }));
  log(found.length === 0
    ? "No one on the waitlist fits this opening."
    : `${found.length} client(s) on the waitlist fit this opening. Offering in order, earliest sign-up first.`);

  for (const progress of state.candidates) {
    if (closeRequested) break;
    const untilStart = opening.startMs - Date.now();
    if (untilStart < MIN_LEAD_MS) {
      await finish("expired", "expired", `The appointment is too close to start (${slotLabel}). Stopped offering. The slot is still open.`);
      await allHandlersFinishedSafely();
      return state;
    }
    const holdMs = effectiveHoldMs(opening.holdMinutes, untilStart);
    const candidate = asCandidate(progress);

    let sent: "sent" | "busy";
    try {
      sent = await acts.sendOffer({ opening, candidate, holdMs });
    } catch {
      progress.status = "send_failed";
      await tell("send_failed", `Could not text ${progress.name} after several tries. Moving to the next person.`, `send_failed:${progress.candidateId}`);
      continue;
    }
    if (sent === "busy") {
      progress.status = "busy";
      log(`${progress.name} is holding an offer for another opening, so they were skipped for this one.`);
      continue;
    }

    const offeredAt = Date.now();
    progress.status = "offered";
    progress.offeredAt = offeredAt;
    pending = { candidateId: progress.candidateId };
    state.status = "offered";
    state.currentOffer = { candidateId: progress.candidateId, name: progress.name, offeredAt, expiresAt: offeredAt + holdMs };
    log(`Offered to ${progress.name} (#${progress.position} in line). Holding for ${holdLabel(holdMs)}.`);

    await condition(() => pending?.resolution !== undefined || closeRequested, holdMs);
    const outcome: Resolution | "timed_out" = pending.resolution ?? (closeRequested ? "withdrawn" : "timed_out");
    pending = undefined;
    state.currentOffer = undefined;
    progress.resolvedAt = Date.now();
    await acts.releaseOffer({ openingId: opening.openingId, candidate });

    if (outcome === "accepted") {
      progress.status = "accepted";
      state.winner = { candidateId: progress.candidateId, name: progress.name };
      await acts.markBooked({ candidateId: progress.candidateId });
      await acts.sendClientNotice({ opening, candidate, kind: "confirmed" });
      await finish("filled", "accepted", `${progress.name} accepted the ${slotLabel}. Please add the booking in Square.`);
      break;
    }
    if (outcome === "declined") {
      progress.status = "declined";
      await tell("declined", `${progress.name} declined. Moving to the next person.`, `declined:${progress.candidateId}`);
    } else if (outcome === "other_time") {
      progress.status = "other_time";
      await acts.sendClientNotice({ opening, candidate, kind: "kept_on_waitlist" });
      await tell("other_time", `${progress.name} asked for a different time and stays on the waitlist. Moving to the next person.`, `other_time:${progress.candidateId}`);
    } else if (outcome === "timed_out") {
      progress.status = "timed_out";
      await tell("timed_out", `${progress.name} did not reply within ${holdLabel(holdMs)}. Moving to the next person.`, `timed_out:${progress.candidateId}`);
    } else {
      progress.status = "withdrawn";
      await acts.sendClientNotice({ opening, candidate, kind: "withdrawn" });
      if (!closeRequested) await tell("withdrawn", `You withdrew the offer to ${progress.name}. Moving to the next person.`, `withdrawn:${progress.candidateId}`);
    }
  }

  if (state.status !== "filled") {
    if (closeRequested) await finish("cancelled", "closed", `Opening closed: ${closeReason}.`);
    else await finish("exhausted", "exhausted", `No one left to offer the ${slotLabel}. It is still open: please fill it by hand.`);
  }
  await allHandlersFinishedSafely();
  return state;

  // Let any in-flight reply (for example a late "yes") finish its message before the Workflow ends.
  async function allHandlersFinishedSafely(): Promise<void> {
    await condition(allHandlersFinished);
  }
}
