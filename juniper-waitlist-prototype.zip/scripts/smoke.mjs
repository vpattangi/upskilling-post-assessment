// End-to-end check of the running app (start it first with `npm run dev`). Plays out one realistic Saturday:
// the first client does not reply, the second says yes, and the first client then replies too late.
const base = process.env.APP_URL ?? "http://localhost:3000";
const api = async (path, options) => {
  const response = await fetch(base + path, { headers: { "content-type": "application/json" }, ...options });
  return response.status === 204 ? {} : response.json();
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const overview = () => api("/api/overview");
async function waitFor(label, check, seconds = 40) {
  for (let i = 0; i < seconds * 4; i += 1) { const o = await overview(); const found = check(o); if (found) return found; await sleep(250); }
  throw new Error(`Timed out waiting for: ${label}`);
}
let failures = 0;
const check = (name, ok) => { console.log(`${ok ? "PASS" : "FAIL"}  ${name}`); if (!ok) failures += 1; };

const saturday = new Date(); saturday.setDate(saturday.getDate() + ((6 - saturday.getDay() + 7) % 7 || 7)); saturday.setHours(14, 30, 0, 0);
const startLocal = new Date(saturday.getTime() - saturday.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

await api("/api/reset", { method: "POST" });
const opened = await api("/api/openings", { method: "POST", body: JSON.stringify({ service: "Women's cut", stylist: "Ana", startLocal, holdMinutes: 0.1 }) });
check("opening started", Boolean(opened.openingId));
const dup = await fetch(base + "/api/openings", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ service: "Women's cut", stylist: "Ana", startLocal, holdMinutes: 0.1 }) });
check("the same slot cannot be opened twice at once (HTTP 409)", dup.status === 409);

await waitFor("Maya has the offer", (o) => o.openings[0]?.currentOffer?.name === "Maya Thompson");
check("earliest sign-up (Maya) is offered first", true);
await waitFor("Sofia has the offer after Maya's 6-second hold times out", (o) => o.openings[0]?.currentOffer?.name === "Sofia Ramirez");
check("no reply from Maya: offer moved to Sofia automatically", true);

const unclear = await api("/api/sms/inbound", { method: "POST", body: JSON.stringify({ from: "+1 555 555 0103", body: "hmm who is this?" }) });
check("an unclear reply is not guessed at; Lena is alerted", unclear.needsPerson === true);
const yes = await api("/api/sms/inbound", { method: "POST", body: JSON.stringify({ from: "+1 555 555 0103", body: "yes please" }) });
check("Sofia's yes is accepted", yes.result?.outcome === "accepted");
const late = await api("/api/sms/inbound", { method: "POST", body: JSON.stringify({ from: "+1 555 555 0101", body: "YES!" }) });
check("Maya's late yes cannot take the slot", late.result?.outcome === "late");

const o = await waitFor("opening filled", (x) => x.openings[0]?.status === "filled" && x);
check("slot is filled by Sofia Ramirez", o.openings[0].winner?.name === "Sofia Ramirez");
const offers = o.messages.filter((m) => m.kind === "offer").map((m) => m.name);
check("Hannah (third in line) was never texted", !offers.includes("Hannah Brooks"));
check("nobody was offered the slot twice", new Set(offers).size === offers.length);
check("Maya was told politely that the slot is gone", o.messages.some((m) => m.kind === "no_longer_available" && m.name === "Maya Thompson"));
// The alert is sent by a follow-up step just after the status flips to "filled", so wait for it.
const alerted = await waitFor("Lena's alerts", (x) => ["timed_out", "accepted", "needs_attention"].every((e) => x.notifications.some((n) => n.event === e)), 10).catch(() => false);
check("Lena was alerted: timed out, accepted, needs attention", Boolean(alerted));
console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) failed.`);
process.exit(failures === 0 ? 0 : 1);
