# Juniper Salon: open-slot assistant (Temporal prototype)

When an appointment opens, Lena or Carla enters it once. The system offers it to waitlisted clients **one at a time, earliest sign-up first**, waits for each reply with a durable timer, moves on automatically after a "no" or silence, and alerts Lena right away. It never lets two clients claim the same opening and never texts the same person twice for the same slot.

**Texts are simulated and nothing is sent to real phones.** Bookings still go in Square by hand. See [what is simulated or left out](#simulated-or-not-built).

## Run it

Requires Node.js 20+ and Docker Desktop (the starter's setup).

```bash
npm install
npm run dev        # Temporal (Docker), the Worker, and the API
```

- App: http://localhost:3000
- Temporal Web UI: http://localhost:8233
- `npm run smoke` (second terminal): plays out a realistic Saturday against the running app and prints PASS/FAIL.
- `npm test`: 19 tests (6 pure-rule, 13 Workflow). The Workflow tests start a real local Temporal dev server in real time and download it on first run (about 40 s). Set `TEMPORAL_TEST_SERVER_PATH` to a local `temporal` binary to run offline.

No Docker? Run `temporal server start-dev`, then `npm run dev:worker` and `npm run dev:api` in two terminals. That is how this was verified.

### Two-minute demo

1. Click **Reset demo data**.
2. **Open a slot**: Women's cut, Ana, a **Saturday afternoon**. Tick **Quick demo** (20-second holds). Three waitlisted clients fit: Maya, Sofia, Hannah. (Maya also signed up twice; she is only texted once.)
3. Maya has the offer, with a countdown. Do nothing: when it runs out she is marked "No reply" and Sofia gets the offer, and Lena gets an alert.
4. Click **Pretend Sofia replies: Yes**. The slot is filled and Lena is told to add it in Square.
5. In **Texts (simulated)**, pretend Maya texts "YES" now. She is politely told the slot is gone and does not take it.
6. Try a new opening and use **Withdraw this offer**, **No**, **Another time**, or **Close opening**.

## What Lena said, and what the prototype does

| Lena said | Prototype |
|---|---|
| Matches by service, availability, stylist preference | `rankCandidates` in `src/policy.ts`; clients can say "any stylist", days, and time of day |
| Earliest on the waitlist goes first | Ranked by sign-up time; tested |
| Staff forget to contact the next person | The Workflow moves on by itself after a decline, "another time", or a timer running out |
| We lose track of replies and how long someone holds an offer | Board shows who holds the offer, a countdown, each client's status, and a plain-language timeline |
| Must never let two clients claim the same opening | One offer at a time, and replies are an **Update** the Workflow handles one at a time; tested with two simultaneous "yes" replies |
| Don't contact someone twice for the same slot | One offer per client per slot; duplicate sign-ups (same phone) merged; sends are idempotent so retries cannot double-text; tested |
| Late replies are a problem; no cutoff today | The hold time *is* the cutoff. A late "yes" gets a polite "no longer available" and cannot take the slot |
| I decide the opening; I can cancel an offer | Open-a-slot form; **Withdraw this offer** (client is told, next client offered) and **Close opening** |
| Matching and moving on should be automatic | Yes; Lena only makes the two decisions above |
| Immediate notice: accepted, declined, timed out, cancelled | **Alerts for Lena** (plus a simulated text to her phone) for each |
| Short-notice openings are hard to fill | The hold shortens as the appointment nears (a quarter of the time left, but never shortened below 2 minutes), and offers stop 10 minutes before the start |
| Square stays as it is | Not touched. The "accepted" alert reminds staff to add the booking |
| Clients must not see others' names, numbers or place in line | Texts contain only the recipient's own first name and the slot; tested |
| "No" or "different time" | Asking for another time sends a kind note and keeps the client on the waitlist; "no" also keeps them on |

## How Temporal is used

- **One Workflow per open slot** (`fillOpeningWorkflow`). Its ID is built from the stylist and time, so the same slot cannot be opened twice at once (HTTP 409).
- **Durable Timer** for each offer's hold. If the server restarts mid-hold, the offer is still counted down.
- **Update `submitReply`** for client replies. It has a validator, returns an immediate answer (`accepted`, `declined`, `other_time`, `late`), and is processed one at a time, which is what guarantees a single winner.
- **Signals** `withdrawOffer` and `closeOpening` for Lena. **Query** `getOpeningState` feeds the board.
- **Activities with a retry policy** for every side effect (texts, alerts, waitlist updates). Each uses an idempotency key, so a retry after a lost confirmation cannot send twice (tested by simulating exactly that).
- `allHandlersFinished` so a reply that arrives as the Workflow ends still completes.

Workflow code is deterministic. All business rules live in `src/policy.ts` with no Node or Temporal imports.

## Simulated or not built

- **Text messages are simulated.** A "sent" text is a row in the outbox, and a client's reply comes in through `POST /api/sms/inbound`, which is the same endpoint a real provider such as Twilio would call. Alerts to Lena are in-app (a text to her phone is simulated the same way).
- **Square is not connected.** Nothing reads or writes bookings.
- **No Google Sheet import.** The waitlist is a small JSON file seeded with fictional clients.
- **No sign-in or roles**, no "STOP" opt-out handling, no quiet hours, no waitlist expiry.
- **The store is a JSON file shared by the API and the Worker.** It is fine for a demo; production needs a real database.

## Assumptions, and what I don't know yet

- **I don't know how long Lena wants to hold an offer.** She said replies are "fairly quick" during the day, with no number. I assumed **15 minutes**, adjustable per opening. To resolve it: pull 2 to 4 weeks of her real texts and see how long clients take to answer, then set the default from that.
- **Late replies are not honored.** I assumed a timed-out client loses the slot. Lena may prefer a short grace period. This needs her decision.
- **One offer at a time per client, across all openings,** so a "YES" is never ambiguous. A client holding one offer is skipped for a second opening.
- **No texting-hours rule,** because she did not mention one. Ask her.
- Times use the server's local time zone.
- Replies are keyword-based. Anything unclear alerts Lena instead of being guessed at.

## Evidence

`evidence/temporal-ui-workflow.png` shows one real run in the Temporal Web UI. See `evidence/README.md`.

## Map

`src/workflows.ts` Workflow and message handlers · `src/activities.ts` side effects · `src/policy.ts` rules · `src/store.ts` demo store · `src/api.ts` API and simulated-text webhook · `src/worker.ts` · `public/` interface · `tests/` · `scripts/smoke.mjs`
